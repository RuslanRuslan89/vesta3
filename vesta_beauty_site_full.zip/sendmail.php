<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $to = "info@vestabeauty.ru";
  $subject = "Новая заявка с сайта";
  $message = "Имя: " . $_POST['name'] . "\n";
  $message .= "Email: " . $_POST['email'] . "\n";
  $message .= "Сообщение: " . $_POST['message'];
  $headers = "From: no-reply@vestabeauty.ru\r\n";
  if (mail($to, $subject, $message, $headers)) {
    echo "OK";
  } else {
    http_response_code(500);
    echo "Ошибка при отправке письма";
  }
}
?>
